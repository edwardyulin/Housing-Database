# UBC-Rez
An entirely original database application that maps out the UBC housing system and allows those learning SQL to try out different types of queries and view their real-time updates - can be viewed at https://www.students.cs.ubc.ca/~ashaaban/milestone3.php
